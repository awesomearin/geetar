package com.company;

public class Ringbuff
{
    private double[] buffer;
    private int f, l, s, stacks;

    public Ringbuff(int capacity) {
        s = 0;
        stacks = capacity;
        buffer = new double[capacity];
        f = 0;
        l = f;
    }
    public int getStacks() {
        return stacks;
    }

    public int getS() {
        return s;
    }

    public boolean isVoid() {
        if (s == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isBig() {
        if (s == stacks) {
            return true;
        } else {
            return false;
        }
    }

    public void enqueue(double inc) {
        if (l == stacks) {
            l = 0;
            enqueue(inc);
        } else if (isBig()) {
            if (l != f) {
                throw new RuntimeException("Critical error received. Please retry.");
            }
            buffer[l] = inc;
            if (f + 1 == stacks) {
                f = 0;
            } else {
                f++;
            }
            l++;
        } else {
            buffer[l] = inc;
            l++;
            s++;
        }
    }

    public double dequeue() {
        if (isVoid()) {
            throw new RuntimeException("The buffer is empty.");
        }

        double inven = buffer[f];
        if (f == stacks-1) {
            f = 0;
        } else {
            f++;
        }
        s--;
        return inven;
    }


}
